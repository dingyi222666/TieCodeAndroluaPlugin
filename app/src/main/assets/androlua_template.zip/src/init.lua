appname="${appName}"
appver="1.0"
packagename="${appPackageName}"
user_permission={
  "INTERNET",
  "WRITE_EXTERNAL_STORAGE",
}
