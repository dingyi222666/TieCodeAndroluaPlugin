require "import"
import "android.app.*"
import "android.os.*"
import "android.widget.*"
import "android.view.*"


activity.setContentView(loadlayout("layout"))
