软件基于开源框架AndroLua+开发，
使用本软件产生的任何后果均与AndroLua+及作者无关，
不要反编译框架了，gihub地址在下边，
https://github.com/nirenr/AndroLua_pro
